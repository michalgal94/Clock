package homework;

import java.applet.Applet;
import java.applet.AudioClip;

public class AnnounceTimeOnSeparateThread implements Runnable {

	private AudioClip[] hourAudio = new AudioClip[12];
	private AudioClip[] minuteAudio = new AudioClip[60];
	// Create audio clips for pronouncing am and pm
	private AudioClip amAudio = Applet.newAudioClip(this.getClass().getResource("audio/am.au"));
	private AudioClip pmAudio = Applet.newAudioClip(this.getClass().getResource("audio/pm.au"));
	private ClockPane clockPane;

	public AnnounceTimeOnSeparateThread(ClockPane clockPane) {
		this.clockPane = clockPane;
		for (int i = 0; i < 12; i++)
			hourAudio[i] = Applet.newAudioClip(this.getClass().getResource("audio/hour" + i + ".au"));
		// Create audio clips for pronouncing minutes
		for (int i = 0; i < 60; i++)
			minuteAudio[i] = Applet.newAudioClip(this.getClass().getResource("audio/minute" + i + ".au"));
		
	}
	

	@Override
	public void run() {
		while (true) {
			if (clockPane.getSecond() == 0) {
				System.out.println("hiiihiiihiiiiii");
				try { // Announce hour
					hourAudio[clockPane.getHour() % 12].play();
					// Time delay to allow hourAudio play to finish
					Thread.sleep(1500);
					// Announce minute
					minuteAudio[clockPane.getMinute()].play();
					// Time delay to allow minuteAudio play to finish
					Thread.sleep(1500);
				} catch (InterruptedException ex) {
				}
				// Announce am or pm
				if (clockPane.getHour() < 12)
					amAudio.play();
				else
					pmAudio.play();
			}
			hourAudio[clockPane.getHour() % 12].stop();
			minuteAudio[clockPane.getMinute()].stop();
		}
	}
}
